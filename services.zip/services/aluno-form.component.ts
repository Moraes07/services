import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlunoService } from '../services/aluno.service';
import { Aluno } from '../models/aluno.model';

@Component({
  selector: 'app-aluno-form',
  templateUrl: './aluno-form.component.html'
})
export class AlunoFormComponent implements OnInit {
  aluno: Aluno = {
    nome: '',
    idade: 0,
    ra: ''
  };

  isEditMode: boolean = false;

  constructor(
    private alunoService: AlunoService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.params['id'];
    if (id) {
      this.isEditMode = true;
      this.alunoService.getAlunoById(id).subscribe((aluno) => (this.aluno = aluno));
    }
  }

  saveAluno(): void {
    if (this.isEditMode) {
      this.alunoService.updateAluno(this.aluno).subscribe(() => {
        this.router.navigate(['/alunos']);
      });
    } else {
      this.alunoService.createAluno(this.aluno).subscribe(() => {
        this.router.navigate(['/alunos']);
      });
    }
  }
}
