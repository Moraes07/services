import { Component, OnInit } from '@angular/core';
import { AlunoService } from '../services/aluno.service';
import { Aluno } from '../models/aluno.model';

@Component({
  selector: 'app-aluno-list',
  templateUrl: './aluno-list.component.html'
})
export class AlunoListComponent implements OnInit {
  alunos: Aluno[] = [];

  constructor(private alunoService: AlunoService) {}

  ngOnInit(): void {
    this.alunoService.getAlunos().subscribe((alunos) => (this.alunos = alunos));
  }

  deleteAluno(id: number): void {
    this.alunoService.deleteAluno(id).subscribe(() => {
      this.alunos = this.alunos.filter((aluno) => aluno.id !== id);
    });
  }
}
