const routes: Routes = [
    { path: '', redirectTo: 'alunos', pathMatch: 'full' },
    { path: 'alunos', component: AlunoListComponent },
    { path: 'alunos/novo', component: AlunoFormComponent },
    { path: 'alunos/editar/:id', component: AlunoFormComponent }
  ];
  